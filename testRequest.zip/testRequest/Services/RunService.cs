﻿using System;
using System.Diagnostics;
using testRequest.Models;

namespace testRequest.Services
{
    public class RunService
    {
        private readonly IHttpClientFactory _factory;


        public RunService(IHttpClientFactory factory) 
        {
            _factory = factory;
        }


        public async Task Run(Stopwatch sw, int threads, int duration, int delay, TestResult result)
        {
            var durationTs= TimeSpan.FromSeconds(duration);
            List<Task> tasks = new List<Task>();

            while (TimeSpan.FromMilliseconds(sw.ElapsedMilliseconds) < durationTs)
            {
                var t = RunUserTask(threads, result);
                tasks.Add(t);
                await Task.Delay(delay);
            }

            await Task.WhenAll(tasks);
            Console.WriteLine($"Run Task Finished");
        }

        public async Task RunUserTask(int threads, TestResult result) 
        {
            List<Task> userTasks = new List<Task>();
            for(int i = 0; i < threads; i++)
            {
                var userTask = RunHttpRequest(i, result);
                userTasks.Add(userTask);
            }

            await Task.WhenAll(userTasks);
            Console.WriteLine($"RunUserTask Task Finished {userTasks.Count}");
        }

        public async Task<bool> RunHttpRequest(int threadIndex, TestResult result) 
        {
            Interlocked.Increment(ref result.RequestCount);
            var client = _factory.CreateClient("testClient");
            var response = await client.GetAsync("/Test/GetTest");
            response.EnsureSuccessStatusCode();
            var res = await response.Content.ReadAsStringAsync();
            result.Results.Add($"{threadIndex}_{res}");
            //Console.WriteLine($"threadIndex={threadIndex}, result={res}");

            return true;

        }
    }
}
