using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Runtime.Versioning;
using testRequest.Models;
using testRequest.Services;

namespace testRequest.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class PerformanceController : ControllerBase
    {

        private readonly ILogger<PerformanceController> _logger;
        private readonly RunService? runService;

        public PerformanceController(ILogger<PerformanceController> logger, RunService runService)
        {
            _logger = logger;
            this.runService = runService;
        }

        [HttpPost("RunTest")]
        public async Task<IActionResult> RunTest()
        {
            try
            {
                int threads = 500;
                int duration = 60;
                int delay = 500;
                TestResult ts = new TestResult();
                var sw = Stopwatch.StartNew();

                var mainTask = runService.Run(sw, threads, duration, delay, ts);

                await ShowPreview(mainTask, sw, ts);

                await mainTask;

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        private async Task ShowPreview(Task mainTask, Stopwatch sw, TestResult ts)
        {
            while (!mainTask.IsCompleted)
            {
                var timeText = TimeSpan.FromMilliseconds(sw.ElapsedMilliseconds).ToString("mm\\:ss");
                Console.WriteLine($"[{timeText}] RequestCount={ts.RequestCount}, Results={ts.Results.Count}");
                await Task.Delay(1000);
            }
        }
    }
}
