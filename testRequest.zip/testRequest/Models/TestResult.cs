﻿using System.Collections.Concurrent;

namespace testRequest.Models
{
    public class TestResult
    {
        public ConcurrentBag<string> Results { get; set; }
        public int RequestCount = 0;
        public TestResult() 
        { 
            Results = new ConcurrentBag<string>();
        }
    }
}
