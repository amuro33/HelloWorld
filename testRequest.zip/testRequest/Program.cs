using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Http;
using Microsoft.Net.Http.Headers;
using testRequest.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddHttpClient("testClient", (HttpClient client) =>
{
    client.BaseAddress = new Uri("http://localhost:5031");
    client.DefaultRequestHeaders.Add(HeaderNames.UserAgent, "mycustomagent");
})
    .ConfigureHttpClient((HttpClient client) => { })
    .ConfigureHttpClient(
       (IServiceProvider provider, HttpClient client) => { });

builder.Services.AddScoped(typeof(RunService));
builder.Services.RemoveAll<IHttpMessageHandlerBuilderFilter>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
